package com.flowrstuff.settings;

public class Display {
	public static int width = 800;
	public static int height = 600;
	public static boolean fullScreen = false;
}
