package com.flowrstuff.graphics;

import java.awt.Color;

public class Dimension {
	int width, height, gridSize;
	Color c1, c2;
	public Dimension(int width, int height, int gridSize, Color c1, Color c2){
		this.width = width;
		this.gridSize = gridSize;
		this.height = height;
		
		//The two colours of the Dimension grid
		this.c1 = c1;
		this.c2 = c2;
	}
	
	public void DrawDimension(){
		
	}
	
	
}
